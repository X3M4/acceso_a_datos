// SPDX-License-Identifier: LGPL-2.1-or-later
// Copyright (c) 2012-2014 Monty Program Ab
// Copyright (c) 2015-2023 MariaDB Corporation Ab

package org.mariadb.jdbc.client;

import org.mariadb.jdbc.message.ServerMessage;

public interface Completion extends ServerMessage {}
