package tema2.p5;

import java.sql.*;

public class Main {

    public static void main(String[] args) throws SQLException {

        ResultSetMetaData mascota = null;
        ResultSetMetaData propietario = null;

        // INICIO DEL PRIMER EJERCICIO
        try {
            String bd = "jdbc:sqlite:/home/chema/Documentos/CFGS-DAM-SEGUNDO/ACCESO_A_DATOS/TEMA2_MANEJO_DE_CONECTORES/"
                    +
                    "practicas/practica1/src/main/resources/veterinaria";

            Connection conn = DriverManager.getConnection(bd);
            Statement stmt = conn.createStatement(); // Cambiado a Statement
            DatabaseMetaData dbmt = conn.getMetaData();

            ResultSet rsTablas = dbmt.getTables(null, "veterinaria", null, null);

            /*La idea era meter el ResultSetMetaData en un List<ResultSetMetaData> pero siempre se imprimen las columnas de propietario
             * Por lo que he hecho dos ResultSetMetada para poder hacer Strings.
            */
            while (rsTablas.next()) {
                String nombre = rsTablas.getString("TABLE_NAME");
                if (!nombre.startsWith("sqlite_autoindex_") && !nombre.startsWith("sqlite_schema")) {
                    String consulta = "SELECT * FROM " + nombre;
                    System.out.println(consulta);
                    ResultSet resultado = stmt.executeQuery(consulta);
                    ResultSetMetaData tabla = resultado.getMetaData();
    
                    System.out.println("\n");
                    /*
                     * La cuestión es que a priori si imprime las columnas de mascota pero luego le pasas mascota a la función
                     * imprimeDatos en la línea 53 e imprime los de propietario.
                     */
                    if (tabla.getTableName(1).equals("mascota")) {
                        mascota = tabla;
                        System.out.println("asignado a mascota");
                        imprimeDatos(mascota);
                    } else if (tabla.getTableName(1).equals("propietario")) {
                        propietario = tabla;
                        System.out.println("asignado a propietario"); 
                        imprimeDatos(propietario);                   
                    }

                }
            }

            imprimeDatos(mascota);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //Creo los Strings para la base de datos
        String database = "CREATE DATABASE ";
        String creaTablaMascota = String.format("CREATA TABLE %s", mascota.getTableName(1));
        String

    }

    public static void imprimeDatos(ResultSetMetaData rsmdt) {
        try {
            int num = rsmdt.getColumnCount();
            for (int i = 1; i <= num; i++) {
                System.out.println(rsmdt.getColumnName(i));
            }
            System.out.println("\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}